<?php
return [
    'yape' => [
        'api_key' => 'TU_API_KEY',
        'api_secret' => 'TU_API_SECRET',
        'endpoint' => 'https://api.yape.com/v1/payments',
    ],
];
