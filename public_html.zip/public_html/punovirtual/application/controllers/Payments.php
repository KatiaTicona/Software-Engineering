<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once APPPATH . 'YapePayment.php';

class Payments extends CI_Controller
{
    public function create_yape_payment()
    {
        $config = include(APPPATH . 'config/config.php');
        $yapePayment = new YapePayment($config['yape']);

        $amount = $this->input->post('amount');
        $response = $yapePayment->createPayment($amount);

        if (isset($response['success']) && $response['success']) {
            echo json_encode(['status' => 'success', 'payment_id' => $response['payment_id']]);
        } else {
            echo json_encode(['status' => 'error', 'message' => $response['message']]);
        }
    }
}
