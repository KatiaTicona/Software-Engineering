<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['stripe_api_key'] = 'YOUR_STRIPE_SECRET_KEY';
$config['stripe_publishable_key'] = 'YOUR_STRIPE_PUBLISHABLE_KEY';
