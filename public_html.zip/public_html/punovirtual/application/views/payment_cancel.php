<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Cancelado</title>
</head>
<body>
    <h1>Pago Cancelado</h1>
    <p>Has cancelado tu pago.</p>
</body>
</html>
