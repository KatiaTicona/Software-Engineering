<form action="payments/create_yape_payment" method="post">
    <label for="amount">Monto:</label>
    <input type="text" id="amount" name="amount" required>
    <button type="submit">Pagar con Yape</button>
</form>
