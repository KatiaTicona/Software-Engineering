<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error en el Pago</title>
</head>
<body>
    <h1>Error en el Pago</h1>
    <p>Hubo un error al procesar tu pago: <?php echo $error; ?></p>
</body>
</html>
