<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: #0056b3;
        }
        
        .modal-body img {
            width: 100%;
            max-width: 200px;
            margin: 10px;
        }
        
        .payment-options {
            display: flex;
            justify-content: space-around;
        }

        .payment-form {
            display: none;
        }
        
        
    </style>
</head>
<body>
    <div class="container">
        <h1>Reservar</h1>
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>
        <form action="<?php echo site_url('welcome/submit_reserva'); ?>" method="post">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required><br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>
            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" required><br>
            <label for="fecha">Fecha:</label>
            <input type="date" id="fecha" name="fecha" required><br>
            <input type="hidden" name="usuario_id" value="<?php echo $this->session->userdata('usuario_id'); ?>">
            <input type="hidden" name="destino_id" value="1"> <!-- Ajusta esto según tu lógica -->
       
        <!-- Botón para abrir la ventana modal de pago -->
        <button class="btn" data-toggle="modal" data-target="#paymentModal">Pagar</button>
        <button class="btn" data-toggle="modal" data-target="#paymentModal">Reservar</button>

        </form>
        
        <!-- Botón para volver a la página de destinos -->
        <form action="<?php echo site_url('destinos'); ?>" method="get" style="margin-top: 20px;">
            <button class="btn btn-secondary" type="submit">Volver atrás</button>
        </form>
        
        
       <!-- Modal de Pago -->
    <div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-labelledby="paymentModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paymentModalLabel">Opciones de Pago</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#yapeModal" data-dismiss="modal">Pagar con Yape</button>
                    <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#tarjetaModal" data-dismiss="modal">Pagar con Tarjeta</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal de Pago con Yape -->
    <div class="modal fade" id="yapeModal" tabindex="-1" role="dialog" aria-labelledby="yapeModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="yapeModalLabel">Pagar con Yape</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="yapeCelular">Celular Yape:</label>
                            <input type="text" class="form-control" id="yapeCelular" required>
                        </div>
                        <div class="form-group">
                            <label for="yapeCodigo">Código de Aprobación:</label>
                            <input type="text" class="form-control" id="yapeCodigo" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Yapear</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal de Pago con Tarjeta -->
    <div class="modal fade" id="tarjetaModal" tabindex="-1" role="dialog" aria-labelledby="tarjetaModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="tarjetaModalLabel">Pagar con Tarjeta</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="payment-form">
                        <div class="form-group">
                            <label for="cardName">Nombre del titular de la tarjeta:</label>
                            <input type="text" class="form-control" id="cardName" required>
                        </div>
                        <div class="form-group">
                            <label for="cardNumber">Número de tarjeta:</label>
                            <input type="text" class="form-control" id="cardNumber" required>
                        </div>
                        <div class="form-group">
                            <label for="cardExpiryMonth">Mes de vencimiento:</label>
                            <input type="text" class="form-control" id="cardExpiryMonth" required>
                        </div>
                        <div class="form-group">
                            <label for="cardExpiryYear">Año de vencimiento:</label>
                            <input type="text" class="form-control" id="cardExpiryYear" required>
                        </div>
                        <div class="form-group">
                            <label for="cardCVC">CVC:</label>
                            <input type="text" class="form-control" id="cardCVC" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Depositar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    

    <!-- Bootstrap and jQuery scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>