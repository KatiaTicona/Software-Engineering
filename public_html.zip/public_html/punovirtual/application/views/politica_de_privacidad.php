<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Política de Privacidad</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
            line-height: 1.6;
        }
        h1 {
            color: #4CAF50;
        }
        p {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Política de Privacidad</h1>
    <p>En Puno Virtual, nos comprometemos a proteger tu privacidad. Esta política describe cómo recopilamos, usamos y protegemos tu información personal.</p>
    <!-- Más detalles sobre la política de privacidad -->
</body>
</html>
