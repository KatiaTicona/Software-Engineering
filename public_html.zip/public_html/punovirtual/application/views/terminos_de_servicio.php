<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Términos de Servicio</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f4f4f4;
            line-height: 1.6;
        }
        h1 {
            color: #4CAF50;
        }
        p {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Términos de Servicio</h1>
    <p>Bienvenido a Puno Virtual. Al utilizar nuestros servicios, aceptas los siguientes términos y condiciones.</p>
    <!-- Más detalles sobre los términos de servicio -->
</body>
</html>
