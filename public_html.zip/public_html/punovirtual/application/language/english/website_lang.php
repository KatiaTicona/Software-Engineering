<?php
$lang['welcome_message'] = 'Community Rural Tourism';
$lang['login'] = 'Login';
$lang['register_here'] = 'Register here';
$lang['username'] = 'Username';
$lang['password'] = 'Password';
$lang['enter'] = 'Enter';
$lang['no_account'] = 'Don\'t have an account?';
$lang['title_login'] = 'Login';
