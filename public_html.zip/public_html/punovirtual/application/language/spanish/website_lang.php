<?php
$lang['welcome_message'] = 'Turismo Rural Comunitario';
$lang['login'] = 'Iniciar Sesión';
$lang['register_here'] = 'Regístrate aquí';
$lang['username'] = 'Usuario';
$lang['password'] = 'Contraseña';
$lang['enter'] = 'Entrar';
$lang['no_account'] = '¿No tienes una cuenta?';
$lang['title_login'] = 'Iniciar Sesión';
