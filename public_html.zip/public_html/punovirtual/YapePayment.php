<?php

class YapePayment
{
    private $apiKey;
    private $apiSecret;
    private $endpoint;

    public function __construct($config)
    {
        $this->apiKey = $config['api_key'];
        $this->apiSecret = $config['api_secret'];
        $this->endpoint = $config['endpoint'];
    }

    public function createPayment($amount, $currency = 'PEN')
    {
        $data = [
            'amount' => $amount,
            'currency' => $currency,
        ];

        $ch = curl_init($this->endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->apiKey,
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }
}
