<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservas</title>
    <script src="https://js.stripe.com/v3/"></script>
    <style>
        /* Estilos para la vista de reservas */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
            max-width: 100%;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;

        }

        form {
            display: flex;
            flex-direction: column;
            
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input, .StripeElement {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }
        
        .StripeElement {
            padding: 12px;
        }

        .btn-primary {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }
        
        .btn-secondary {
            width: 100%;
            padding: 10px;
            background-color: #6c757d;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }

        .success {
            color: green;
            text-align: center;
        }

        p {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Reservar</h1>
        <?php if ($this->session->flashdata('success')): ?>
            <p class="success"><?php echo $this->session->flashdata('success'); ?></p>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form id="reservation-form" action="<?php echo site_url('welcome/submit_reserva'); ?>" method="post">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="telefono">Teléfono:</label>
            <input type="text" id="telefono" name="telefono" required>
            <label for="fecha">Fecha:</label>
            <input type="date" id="fecha" name="fecha" required>
            <input type="hidden" name="usuario_id" value="<?php echo $this->session->userdata('usuario_id'); ?>">
            <input type="hidden" name="destino_id" value="1"> <!-- Ajusta esto según tu lógica -->
            <button type="submit" class="btn-primary">Reservar</button>
        </form>
        <br>
        <form id="payment-form">
            <div id="card-element" class="StripeElement">
                <!-- Stripe Element will be inserted here -->
            </div>
            <div id="card-errors" role="alert" class="error"></div>
            <button id="submit-button" class="btn-secondary">Pagar con Tarjeta</button>
        </form>
    </div>

    <script>
        // Initialize Stripe
        var stripe = Stripe('<?php echo $this->config->item('stripe_publishable_key'); ?>');
        var elements = stripe.elements();

        // Create an instance of the card Element
        var card = elements.create('card');
        card.mount('#card-element');

        // Handle form submission
        var form = document.getElementById('payment-form');
        form.addEventListener('submit', function(event) {
            event.preventDefault();

            stripe.createPaymentMethod('card', card).then(function(result) {
                if (result.error) {
                    // Inform the user if there was an error
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = result.error.message;
                } else {
                    // Send the token to your server
                    stripeTokenHandler(result.paymentMethod.id);
                }
            });
        });

        function stripeTokenHandler(paymentMethodId) {
            fetch('<?php echo base_url('StripePayments/create_payment_intent'); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    payment_method_id: paymentMethodId
                })
            }).then(function(result) {
                return result.json();
            }).then(function(data) {
                if (data.error) {
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = data.error;
                } else {
                    window.location.href = '<?php echo base_url('StripePayments/success'); ?>';
                }
            });
        }
    </script>
</body>
</html>

