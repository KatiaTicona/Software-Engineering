-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: punoedp_turismo_rural
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `punoedp_turismo_rural`
--


--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(25) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`id`, `usuario`, `password`) VALUES (0,'loba@gmail.com','123456'),(0,'memito12@gmail.com','61e83dec923c3592f8dfbc967419a9f4'),(0,'lobis12@gmail.com','e99a18c428cb38d5f260853678922e03'),(0,'Diego@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'kath12@gmail.com','25f9e794323b453885f5181f1b624d0b'),(0,'lobis@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'memito@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'lindell2468@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'ivan@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela18@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'pablo@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'memito12@gmail.com','61e83dec923c3592f8dfbc967419a9f4'),(0,'nancy@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'morita@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'morita@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'anita@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'w1@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'ariana@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'ariana@gmail.com','8d70d8ab2768f232ebe874175065ead3'),(0,'fred','202cb962ac59075b964b07152d234b70'),(0,'rosmirian@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'gabriel@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'manuela@gmail.com','e10adc3949ba59abbe56e057f20f883e'),(0,'memito12@gmail.com','$2y$10$gdr6aii8bNMVKZxYW7KmLePFFC/1iqZKwKyi//8X1T8kn8ilet0s.'),(0,'camila@gmail.com','$2y$10$4K1RGjXaS6Of1AZyRTThCOMaZSF83fOS7J25eHv2bulgUJTwX8LOW'),(0,'valeria@gmail.com','$2y$10$Kn9/naKQG8lvZNiLG16e3O5hKGqzp/I8Mv.OWuowIWx5zwsBf/A3y'),(0,'maria@gmail.com','$2y$10$QiCzVKiFAy2lcuydl9AWWuiTYEm2Ys6lJBXrOA2FBYbbsxpyqFahm');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'punoedp_turismo_rural'
--

--
-- Dumping routines for database 'punoedp_turismo_rural'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-18 21:20:56
